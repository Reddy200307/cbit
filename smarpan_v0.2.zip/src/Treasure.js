export default function Treasure(){
    return(
        <>
        <h1>hello</h1>
        </>
    );
}