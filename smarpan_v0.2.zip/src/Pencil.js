export default function Pencil(){
    return (<>
    <div className="w3-container">
        <table class="w3-table-all">
            <tr>
            <td className="w3-center">Event</td>
            <td className="w3-center"> Pencil Sketching and Painting</td>
            </tr>
            <tr>
            <td className="w3-center">co-ordinator incharge </td>
            <td className="w3-left"><ol>
                <li className="w3-list">Prof-Monish.NV (CV)</li>
                <li className="w3-list">Prof Chowda Reddy C (ME)</li>
                </ol></td>
                </tr>
                <tr>
            <td className="w3-center">Registration links</td>
            <td className="w3-center"> 
                <li className="w3-list w3-border  w3-button w3-hover-purple">Individual Registration Link</li>
                <li className="w3-list w3-button "></li>
                <li className="w3-list w3-button w3-border w3-hover-purple">Group registration link</li></td>
            </tr>
            <tr>
                <td className="w3-center">rules and regulations </td>
                <td className="w3-center"><ol className="w3-list">
                    <li>rule 1</li>
                    <li>rule 2</li>
                    </ol></td>
            </tr>
        </table>
    </div>
    
    </>);
}