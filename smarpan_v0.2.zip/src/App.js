// import { useState } from 'react';
// import './App.css';
import Home from './home.jsx';
// import Gallery from './components/gallery/gallery';
// import Navbar from './components/navbar/navbar';
// // import { BrowserRouter, Routes, Route } from 'react-router-dom'
// import MyTable from './components/events/events';


function App() {
  return (
    < Home />
  );
}

export default App;
