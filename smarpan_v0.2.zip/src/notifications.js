import notifi1 from "./gallery-samarpan/noti3.jpeg";
import notifi2 from "./gallery-samarpan/img1.jpeg";
import notifi3 from "./gallery-samarpan/IMG01 (1).jpg";

export default function Notification(){
    return (<>
    	    <div className="w3-card w3-container">
    <h3>New Notification 15/05/2023</h3>
    <img className="w3-image w3-responsive" src={notifi1} alt="noti_image"/>
    </div>
    	    <div className="w3-card w3-container">
    <h3>New Notification 11:00 AM 12/05/2023</h3>
    <img className="w3-image w3-responsive" src={notifi2} alt="noti_image"/>
    </div>
    <div className="w3-card w3-container">
    <h3>New Notification 3:12 PM 11/05/2023</h3>
    <img className="w3-image w3-responsive" src={notifi3} alt="noti_image"/>
    </div>
    </>)
}
