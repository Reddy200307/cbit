import first from "./gallery-samarpan/gallery/img1 (1).jpeg"
export const gallery_data=[
{link:{first},visible:"true"},
{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/samarpan%2012-05-23%20pics/img2.jpeg?raw=true",visible:"true"},
{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/samarpan%2012-05-23%20pics/img5.jpeg?raw=true",visible:"true"},
{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/samarpan%2012-05-23%20pics/img7.jpeg?raw=true",visible:"true"},
{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/samarpan%2012-05-23%20pics/img6.jpeg?raw=true",visible:"true"},
{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/samarpan%2012-05-23%20pics/img4.jpeg?raw=true",visible:"true"},
{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/samarpan%2012-05-23%20pics/img3.jpeg?raw=true",visible:"true"}]; 
