// import { gallery_data } from  "./data_gallery.js";
import gal1 from "./gallery-samarpan/gallery/img1 (1).jpeg";
import gal2 from "./gallery-samarpan/gallery/img2.jpeg"
import gal3 from "./gallery-samarpan/gallery/img5.jpeg"
import gal4 from "./gallery-samarpan/gallery/img7.jpeg"
import gal5 from "./gallery-samarpan/gallery/img6.jpeg"
import gal6 from "./gallery-samarpan/gallery/img4.jpeg"
import gal7 from "./gallery-samarpan/gallery/img3.jpeg"
// import {lazy_load} from "./lazy_load_img.js";
// import { LazyLoadImage } from "react-lazy-load-image-component";
// import  gallery_data from "https://cdn.jsdelivr.net/gh/it-is-jayvardhan/jay-projects@main/data_gallery.js";
import "./gallery.css";

				


export default function Gallery(){
	return(	<>
			<div className="w3-container w3-center  w3-padding-16">
		<h1>GALLERY</h1>
		<br /> < br />
		<div>
			<div className="first w3-card w3-padding-32 w3-container">
			<img className="w3-image  w3-center" src={gal1} alt="loading "  />
			
			</div>
			<br /> < br />
			<div className="first w3-card w3-padding-32 w3-container">
			<img className="w3-image  w3-center" src={gal2} alt="loading "  />
			
			</div>
			<br /> < br />
			<div className="first w3-card w3-padding-32 w3-container">
			<img className="w3-image  w3-center" src={gal3} alt="loading "  />
			
			</div>
			<br /> < br />
			<div className="first w3-card w3-padding-32 w3-container">
			<img className="w3-image  w3-center" src={gal4} alt="loading "  />
			
			</div>
			<br /> < br />
			<div className="first w3-card w3-padding-32 w3-container">
			<img className="w3-image  w3-center" src={gal5} alt="loading "  />
			
			</div>
			<br /> < br />
			<div className="first w3-card w3-padding-32 w3-container">
			<img className="w3-image  w3-center" src={gal6} alt="loading "  />
			
			</div>
			<br /> < br />
			<div className="first w3-card w3-padding-32 w3-container">
			<img className="w3-image  w3-center" src={gal7} alt="loading "  />
			
			</div>
			<br /> < br />

			</div>
						
						
		</div>
		
		</>
	);
}



{/* <div>
<div className="first w3-card w3-padding-32 w3-container">
<img className="w3-image  w3-center" src={gal1} alt="loading "  />

</div>
<br /> < br />
</div> */}